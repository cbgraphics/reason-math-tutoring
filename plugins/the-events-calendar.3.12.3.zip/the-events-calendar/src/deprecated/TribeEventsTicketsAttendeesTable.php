<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Tickets__Attendees_Table' );


	class TribeEventsTicketsAttendeesTable extends Tribe__Events__Tickets__Attendees_Table {

	}