<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__PUE__Checker' );


	class TribePluginUpdateEngineChecker extends Tribe__Events__PUE__Checker {

	}