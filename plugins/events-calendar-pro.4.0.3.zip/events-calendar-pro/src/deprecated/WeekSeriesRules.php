<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Date_Series_Rules__Week' );


	class WeekSeriesRules extends Tribe__Events__Pro__Date_Series_Rules__Week {

	}