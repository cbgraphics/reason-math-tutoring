<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Templates__Single_Venue' );


	class Tribe_Events_Pro_Single_Venue_Template extends Tribe__Events__Pro__Templates__Single_Venue {

	}