********************************************************

  The Events Category Colors I18n
  ==============
  You want to translate, help, or improve a translation!
  
  Join our WP-Translations Community at
  https://www.transifex.com/projects/p/category-colors/

  More infos at http://wp-translations.org/

********************************************************