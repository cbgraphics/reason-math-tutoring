<?php

if ( ! class_exists( 'Tribe__Events__Pro__Main' ) && class_exists( 'TribeEventsPro' ) ) {
	class Tribe__Events__Pro__Main extends TribeEventsPro {}
}
