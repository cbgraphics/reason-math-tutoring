<?php

if ( ! class_exists( 'Tribe__Events__Filterbar__View' ) && class_exists( 'TribeEventsFilterView' ) ) {
	class Tribe__Events__Filterbar__View extends TribeEventsFilterView {}
}
