#legend_box { font: bold 10px/4em sans-serif; text-align: center; }

#legend a { text-decoration: none; }

#tribe-events #legend li {
	display: inline-block;
	list-style-type: none;
	padding: 7px;
	margin-left: 0.7em;
}

#legend_box #legend li span { cursor: pointer; }
